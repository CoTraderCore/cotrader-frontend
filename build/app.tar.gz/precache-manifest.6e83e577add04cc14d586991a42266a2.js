self.__precacheManifest = [
  {
    "revision": "973a2d5c996d021b25b6",
    "url": "/static/css/main.fffaedb9.chunk.css"
  },
  {
    "revision": "973a2d5c996d021b25b6",
    "url": "/static/js/main.06411170.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "32d1365cfd1860c0c37d",
    "url": "/static/css/2.4a3fd318.chunk.css"
  },
  {
    "revision": "32d1365cfd1860c0c37d",
    "url": "/static/js/2.a9df4e91.chunk.js"
  },
  {
    "revision": "e88a3fa8ccf5dea116de6090764f5dcb",
    "url": "/index.html"
  }
];